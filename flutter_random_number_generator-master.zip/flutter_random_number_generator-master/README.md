# Random Number Generator

A simple app to generate random numbers

## Screenshot
![Random Number Generator](demo/demo.gif)

## Dependencies
No dependencies

## Dev dependencies
- flutter_launcher_icons: Just for build launcher Icons

## See more
For more information about me or other projects: [brenomachado.dev](https://brenomachado.dev)